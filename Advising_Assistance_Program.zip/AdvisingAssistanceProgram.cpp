#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>

// Define a struct to represent a course node in the binary tree
struct CourseNode {
    std::string courseNumber; // Course number
    std::string title; // Course title
    std::string prerequisites; // Course prerequisites
    CourseNode* left; // Pointer to the left child node
    CourseNode* right; // Pointer to the right child node

    // Constructor to initialize the course node
    CourseNode(const std::string& courseNumber, const std::string& title, const std::string& prerequisites)
        : courseNumber(courseNumber), title(title), prerequisites(prerequisites), left(nullptr), right(nullptr) {}
};

// Define a class for the binary tree data structure
class BinaryTree {
private:
    CourseNode* root; // Pointer to the root node of the binary tree

    // Private method to recursively insert a course node into the binary tree
    CourseNode* insertCourse(CourseNode* node, const std::string& courseNumber, const std::string& title, const std::string& prerequisites) {
        // If the current node is null, create a new node
        if (node == nullptr) {
            return new CourseNode(courseNumber, title, prerequisites);
        }

        // Insert the course node into the appropriate subtree based on the course number
        if (courseNumber < node->courseNumber) {
            node->left = insertCourse(node->left, courseNumber, title, prerequisites);
        } else {
            node->right = insertCourse(node->right, courseNumber, title, prerequisites);
        }

        return node;
    }

public:
    // Constructor to initialize the binary tree
    BinaryTree() : root(nullptr) {}

    // Public method to insert a course into the binary tree
    void insert(const std::string& courseNumber, const std::string& title, const std::string& prerequisites) {
        root = insertCourse(root, courseNumber, title, prerequisites);
    }

    // Public method to load course data from a file and construct the binary tree
    void loadDataStructure(const std::string& filename) {
        std::ifstream file(filename); // Open the file for reading
        if (!file.is_open()) {
            std::cerr << "Error: Unable to open file " << filename << std::endl; // Display error message if file cannot be opened
            return;
        }

        std::string line;
        // Read each line from the file
        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string courseNumber, title, prerequisites;
            // Parse the line into course number, title, and prerequisites
            if (std::getline(ss, courseNumber, ',') &&
                std::getline(ss, title, ',')) {
                // If there are more data fields in the line, assign them to prerequisites
                if (std::getline(ss, prerequisites)) {
                    insert(courseNumber, title, prerequisites); // Insert the course into the binary tree
                } else {
                    insert(courseNumber, title, "No prerequisites for course\n"); // Insert the course with empty prerequisites
                }
            } else {
                std::cerr << "ERROR: Insufficient parameters for course: " << line << std::endl; // Display error message for incomplete data
            }
        }
        file.close(); // Close the file
    }

    // Public method to get the root node of the binary tree
    CourseNode* getRoot() const {
        return root;
    }
};

// Function to recursively print the list of courses in sorted order
void printCourseList(CourseNode* node) {
    if (node == nullptr) return;

    printCourseList(node->left); // Print left subtree
    std::cout << node->courseNumber << " - " << node->title; // Print course number and title
    std::cout << std::endl;
    printCourseList(node->right); // Print right subtree
}

// Function to print the information of a specific course
void printCourseInformation(CourseNode* node, const std::string& courseNumber) {
    if (node == nullptr) {
        std::cout << "Course not found." << std::endl; // Display message if course is not found
        return;
    }

    if (node->courseNumber == courseNumber) {
        std::cout << "Course Number: " << node->courseNumber << std::endl; // Print course number
        std::cout << "Title: " << node->title << std::endl; // Print course title
        std::cout << "Prerequisites: \n" << node->prerequisites << std::endl; // Print course prerequisites
        return;
    }

    // Traverse the binary tree to find the specified course
    if (courseNumber < node->courseNumber) {
        printCourseInformation(node->left, courseNumber); // Search left subtree
    } else {
        printCourseInformation(node->right, courseNumber); // Search right subtree
    }
}

// Main function
int main() {
    BinaryTree binaryTree; // Create an instance of the binary tree

    std::cout << "Welcome to the Advising Assistance Program!\n\n"; // Display welcome message

    while (true) {
        std::cout << "Menu:\n"; // Display menu options
        std::cout << "1. Load Data Structure\n";
        std::cout << "2. Print Course List\n";
        std::cout << "3. Print Course\n";
        std::cout << "4. Exit \n";
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice; // Read user choice

        // Process user choice using a switch statement
        switch (choice) {
            case 1: {
                std::string filename;
                std::cout << "Enter the file name followed by the proper extension(.txt/.csv): ";
                std::cin >> filename; // Prompt user to enter file name
                binaryTree.loadDataStructure(filename); // Load course data from file
                break;
            }
            case 2: {
                std::cout << "Here is your sample schedule:\n\n";
                printCourseList(binaryTree.getRoot()); // Print list of courses
                break;
            }
            case 3: {
                std::string courseNumber;
                std::cout << "Please enter the course number: ";
                std::cin >> courseNumber; // Prompt user to enter course number
                printCourseInformation(binaryTree.getRoot(), courseNumber); // Print information of specified course
                break;
            }
            case 4:
                std::cout << "Thank you for using the Advising Program!\n"; // Display exit message
                std::system("pause"); // Pause execution
                return 0; // Exit program
            default:
                std::cout << "Invalid option. Please try again.\n\n"; // Display error message for invalid input
        }
    }

    return 0;
}
